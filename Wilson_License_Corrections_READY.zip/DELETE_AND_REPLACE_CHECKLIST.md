# Wilson Apache-2.0 Cleanup

DELETE/REPLACE these old repository files:
1. LICENSE
2. NOTICE
3. README.md
4. GOVERNANCE.md
5. CITATION.cff
6. pyproject.toml

Use the corrected files in this folder.

Also DELETE AND REBUILD any artifacts created before the license correction:
- dist/wilson_open_middleware-0.1.0-py3-none-any.whl
- any old .tar.gz source distribution built from the old metadata
- Wilson_v0.1_Open_Reference_Middleware_RELEASE.zip
- Wilson_v0.1_Open_Reference_Middleware_RELEASE.tar.gz
- MANIFEST.sha256 (regenerate after replacement/rebuild)

Do NOT delete Apache-2.0 references that explicitly describe the third-party IBM Granite
model. Those references identify the model's own license and do not license Wilson.

After replacement, rebuild the wheel/sdist and regenerate release hashes before publishing.
