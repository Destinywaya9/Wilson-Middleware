# Changelog

## 0.1.0 — 2026-09-16

Initial open reference release of Wilson middleware.

- model-agnostic core;
- explicit QRTM input path;
- immutable P2 audit cursor;
- P3/D12/QTL-Sphere audit registry;
- `0 = M_E` reference identity;
- mandatory versioned ethics checkpoint at every `0,0`;
- request and output ethics checks;
- separate middleware, ethics, and QPU ledgers;
- IBM QPU read-only evidence lane;
- Colab public-review harness;
- independent verifier and reference outputs;
- installable Python wheel.
