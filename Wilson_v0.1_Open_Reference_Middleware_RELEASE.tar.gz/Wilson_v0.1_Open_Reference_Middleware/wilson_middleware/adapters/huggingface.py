from __future__ import annotations
from ..models import BaseModelAdapter


class HFTransformersAdapter(BaseModelAdapter):
    backend = "huggingface_transformers"

    def __init__(self, model_id="ibm-granite/granite-3.3-2b-instruct", revision="main", max_new_tokens=128):
        import torch
        from transformers import AutoTokenizer, AutoModelForCausalLM
        from huggingface_hub import model_info
        self.model_id = model_id
        self.max_new_tokens = int(max_new_tokens)
        info = model_info(model_id, revision=revision)
        self.revision = info.sha
        card = getattr(info, "cardData", None) or {}
        try:
            self.license = card.get("license", "unknown")
        except Exception:
            self.license = "unknown"
        self.tokenizer = AutoTokenizer.from_pretrained(model_id, revision=self.revision)
        dtype = torch.float16 if torch.cuda.is_available() else torch.float32
        self.model = AutoModelForCausalLM.from_pretrained(
            model_id, revision=self.revision, torch_dtype=dtype, device_map="auto"
        )
        self.model.eval()

    def generate(self, text: str) -> str:
        import torch
        messages = [
            {"role": "system", "content": self.system_prompt},
            {"role": "user", "content": text},
        ]
        rendered = self.tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        inputs = self.tokenizer(rendered, return_tensors="pt").to(self.model.device)
        with torch.no_grad():
            output = self.model.generate(
                **inputs,
                max_new_tokens=self.max_new_tokens,
                do_sample=False,
                pad_token_id=self.tokenizer.eos_token_id,
            )
        new_tokens = output[0, inputs["input_ids"].shape[1]:]
        return self.tokenizer.decode(new_tokens, skip_special_tokens=True).strip()
