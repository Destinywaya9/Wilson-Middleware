from __future__ import annotations
from typing import Dict, Any
from .audit import sha256_text


class BaseModelAdapter:
    model_id = "abstract"
    revision = "unknown"
    license = "unknown"
    backend = "abstract"
    system_prompt = "Answer directly and concisely. Do not provide chain-of-thought."

    def generate(self, text: str) -> str:
        raise NotImplementedError

    def provenance(self) -> Dict[str, Any]:
        return {
            "model_id": self.model_id,
            "revision": self.revision,
            "license": self.license,
            "backend": self.backend,
            "system_prompt_sha256": sha256_text(self.system_prompt),
        }


class DeterministicReviewStub(BaseModelAdapter):
    model_id = "deterministic-review-stub"
    revision = "v1"
    license = "not-a-language-model"
    backend = "offline_validation_stub"

    def generate(self, text: str) -> str:
        clean = " ".join(text.strip().split())
        return f"[REVIEW-STUB] {clean[:180]}"
