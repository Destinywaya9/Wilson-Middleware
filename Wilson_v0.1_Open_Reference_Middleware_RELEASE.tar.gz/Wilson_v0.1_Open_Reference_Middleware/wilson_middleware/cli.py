from __future__ import annotations
import argparse, json
from . import WilsonMiddleware, QRTMObservation, DeterministicReviewStub


def main():
    ap=argparse.ArgumentParser(description="Wilson open reference middleware demo")
    ap.add_argument("text")
    ap.add_argument("--phase", type=float, default=0.0)
    ap.add_argument("--inadmissible", action="store_true")
    ap.add_argument("--spike", action="store_true")
    args=ap.parse_args()
    w=WilsonMiddleware(DeterministicReviewStub())
    row=w.handle(args.text,QRTMObservation(args.phase,not args.inadmissible,args.spike))
    print(json.dumps(row,indent=2,default=str))

if __name__=="__main__": main()
