from __future__ import annotations
import math
from dataclasses import dataclass


def quantize_signed(x: float, levels: int = 17) -> float:
    x = max(-1.0, min(1.0, float(x)))
    j = round((x + 1.0) * (levels - 1) / 2.0)
    return (2.0 * j / (levels - 1)) - 1.0


@dataclass(frozen=True)
class QRTMObservation:
    phase_rad: float
    admissible: bool = True
    spike_flag: bool = False
    source: str = "explicit_review_channel"

    def evaluate(self) -> dict:
        raw = math.sin(float(self.phase_rad))
        weight = quantize_signed(raw, levels=17)
        accepted = bool(self.admissible and not self.spike_flag)
        return {
            "phase_rad": float(self.phase_rad),
            "raw_sinusoidal_signature": raw,
            "qrtm_weight": weight,
            "qrtm_admissible_input": bool(self.admissible),
            "qrtm_spike_flag_input": bool(self.spike_flag),
            "qrtm_accepted": accepted,
            "qrtm_source": self.source,
        }
