P2_FULL = ("3,3", "0,0", "0,1", "1,2", "2,1", "1,0", "0,0", "Delay(200)")
P2_POSITION_LABELS = (
    "3,3 entry",
    "0,0 reference",
    "0,1",
    "1,2",
    "2,1",
    "1,0",
    "0,0 return",
    "Delay(200) post-return spacing",
)
P3_FORM = "[P2_1 ⊗ D_1, P2_2 ⊗ D_2, P2_3 ⊗ D_3]"
ECHO_MERIDIAN_ZERO = "0 = M_E"
D12 = (
    ("+X", "P3_1"), ("-X", "P3_1"), ("+Y", "P3_1"), ("-Y", "P3_1"),
    ("+Z", "P3_2"), ("-Z", "P3_2"), ("XY+", "P3_2"), ("XY-", "P3_2"),
    ("YZ+", "P3_3"), ("YZ-", "P3_3"), ("ZX+", "P3_3"), ("ZX-", "P3_3"),
)
EVENT_DIRECTION_RULE = "UNASSIGNED_CANONICAL_RULE_NOT_DISCLOSED"
