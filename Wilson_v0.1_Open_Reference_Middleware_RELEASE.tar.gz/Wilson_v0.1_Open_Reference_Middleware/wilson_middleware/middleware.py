from __future__ import annotations
import json, time
from typing import Optional
from .audit import HashChain, sha256_text
from .canon import P2_FULL, P2_POSITION_LABELS, P3_FORM, ECHO_MERIDIAN_ZERO, D12, EVENT_DIRECTION_RULE
from .qrtm import QRTMObservation
from .ethics import TransparentEthicsAdapter
from .models import BaseModelAdapter


class WilsonMiddleware:
    def __init__(self, model: BaseModelAdapter, ethics: TransparentEthicsAdapter | None = None, log_plaintext: bool = True):
        self.model = model
        self.ethics = ethics or TransparentEthicsAdapter()
        self.log_plaintext = bool(log_plaintext)
        self.kernel = tuple(P2_FULL)
        self.kernel_sha256 = sha256_text(json.dumps(self.kernel))
        self.middleware_chain = HashChain("prev_row_hash", "row_hash")
        self.ethics_chain = HashChain("prev_ethics_hash", "ethics_row_hash")

    def _record_ethics(self, event_id, request_id, p2_pos, p2_label, p2_stage, evaluation):
        zero_required = p2_stage == "0,0"
        for rr in evaluation["results"]:
            self.ethics_chain.append({
                "event_id": event_id,
                "request_id": request_id,
                "p2_cycle_position": p2_pos,
                "p2_position_label": p2_label,
                "p2_stage": p2_stage,
                "zero_checkpoint_required": zero_required,
                "ethics_phase": evaluation["phase"],
                "ethics_policy_sha256": evaluation["policy_sha256"],
                "ethics_detector_id": evaluation["detector_id"],
                "ethics_detector_sha256": evaluation["detector_sha256"],
                **rr,
            })

    def handle(self, text: str, observation: QRTMObservation, request_id: Optional[str] = None) -> dict:
        event_id = len(self.middleware_chain.rows)
        request_id = request_id or f"req-{event_id:04d}"
        p2_pos = event_id % len(self.kernel)
        p2_stage = self.kernel[p2_pos]
        p2_label = P2_POSITION_LABELS[p2_pos]
        zero_checkpoint = p2_stage == "0,0"
        zero_kind = "ZERO_REFERENCE" if p2_pos == 1 else ("ZERO_RETURN" if p2_pos == 6 else "NONE")

        q = observation.evaluate()
        request_ethics = self.ethics.evaluate(text, "REQUEST", mandatory_zero_checkpoint=zero_checkpoint)
        self._record_ethics(event_id, request_id, p2_pos, p2_label, p2_stage, request_ethics)

        qrtm_ok = bool(q["qrtm_accepted"])
        ethics_ok = bool(request_ethics["passed"])
        admitted = qrtm_ok and ethics_ok
        model_called = False
        raw_model_output = ""
        emitted_output = ""
        output_ethics = None
        if admitted:
            raw_model_output = self.model.generate(text)
            model_called = True
            output_ethics = self.ethics.evaluate(raw_model_output, "OUTPUT", mandatory_zero_checkpoint=zero_checkpoint)
            self._record_ethics(event_id, request_id, p2_pos, p2_label, p2_stage, output_ethics)
            if output_ethics["passed"]:
                emitted_output = raw_model_output

        if not ethics_ok:
            intake_status = "REJECTED_ETHICS"
        elif not qrtm_ok:
            intake_status = "REJECTED_QRTM"
        else:
            intake_status = "ADMITTED"
        response_emitted = bool(model_called and output_ethics and output_ethics["passed"])
        emission_status = "EMITTED" if response_emitted else ("WITHHELD_ETHICS_OUTPUT" if model_called else "NO_MODEL_CALL")
        zero_pass = bool(request_ethics["passed"] and (output_ethics is None or output_ethics["passed"])) if zero_checkpoint else True

        row = {
            "event_id": event_id,
            "request_id": request_id,
            "timestamp_unix": time.time(),
            "p2_cycle_position": p2_pos,
            "p2_position_label": p2_label,
            "p2_stage": p2_stage,
            "p2_kernel_sha256": self.kernel_sha256,
            "at_folded_zero_reference": zero_checkpoint,
            "zero_checkpoint_kind": zero_kind,
            "zero_ethics_checked": zero_checkpoint,
            "zero_ethics_pass": zero_pass if zero_checkpoint else True,
            "ethics_policy_id": self.ethics.policy["policy_id"],
            "ethics_policy_sha256": self.ethics.policy_sha256,
            "ethics_detector_id": self.ethics.detector_id,
            "ethics_detector_sha256": self.ethics.detector_sha256,
            "ethics_request_pass": bool(request_ethics["passed"]),
            "ethics_request_violations": "|".join(request_ethics["violations"]),
            "ethics_request_tags": "|".join(request_ethics["matched_tags"]),
            "ethics_output_checked": output_ethics is not None,
            "ethics_output_pass": bool(output_ethics["passed"]) if output_ethics is not None else True,
            "ethics_output_violations": "|".join(output_ethics["violations"]) if output_ethics is not None else "",
            "overlay_audit_state": "CLEAR_AFTER_ETHICS" if zero_checkpoint and zero_pass else ("BLOCKED_AT_ZERO" if zero_checkpoint else "NOT_DEMONSTRATED"),
            **q,
            "intake_status": intake_status,
            "model_called": model_called,
            "response_emitted": response_emitted,
            "emission_status": emission_status,
            "model_id": self.model.model_id,
            "model_revision": self.model.revision,
            "model_backend": self.model.backend,
            "request_text": text if self.log_plaintext else "[HASH_ONLY]",
            "request_sha256": sha256_text(text),
            "model_output": emitted_output if self.log_plaintext else ("[HASH_ONLY]" if response_emitted else ""),
            "model_output_sha256": sha256_text(emitted_output) if response_emitted else "",
            "raw_model_output_sha256": sha256_text(raw_model_output) if model_called else "",
            "p3_form": P3_FORM,
            "p3_slots": "P3_1|P3_2|P3_3",
            "qtl_zero_echo_identity": ECHO_MERIDIAN_ZERO,
            "d12_registry_size": len(D12),
            "event_direction_assignment": EVENT_DIRECTION_RULE,
        }
        return self.middleware_chain.append(row)

    @property
    def rows(self):
        return self.middleware_chain.rows

    @property
    def ethics_rows(self):
        return self.ethics_chain.rows

    def verify_kernel(self) -> bool:
        return self.kernel == P2_FULL and self.kernel_sha256 == sha256_text(json.dumps(P2_FULL))

    def verify_chain(self) -> bool:
        return self.middleware_chain.verify()

    def verify_ethics_chain(self) -> bool:
        return self.ethics_chain.verify()
