# Package data for Wilson ethics policy.
