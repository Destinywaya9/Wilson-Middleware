from __future__ import annotations
import hashlib, json
from dataclasses import dataclass, field
from typing import Any, Dict, List


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def canonical_hash(obj: Dict[str, Any]) -> str:
    payload = json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":"), default=str)
    return sha256_text(payload)


@dataclass
class HashChain:
    prev_key: str
    hash_key: str
    genesis: str = "GENESIS"
    rows: List[Dict[str, Any]] = field(default_factory=list)
    last_hash: str = "GENESIS"

    def append(self, row: Dict[str, Any]) -> Dict[str, Any]:
        d = dict(row)
        d[self.prev_key] = self.last_hash
        d[self.hash_key] = canonical_hash(d)
        self.last_hash = d[self.hash_key]
        self.rows.append(d)
        return d

    def verify(self) -> bool:
        prev = self.genesis
        for row in self.rows:
            if row[self.prev_key] != prev:
                return False
            payload = {k: v for k, v in row.items() if k != self.hash_key}
            if canonical_hash(payload) != row[self.hash_key]:
                return False
            prev = row[self.hash_key]
        return True
