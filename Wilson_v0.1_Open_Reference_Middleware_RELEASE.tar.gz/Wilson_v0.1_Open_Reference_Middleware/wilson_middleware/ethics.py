from __future__ import annotations
import hashlib, json, re
from importlib.resources import files


def load_policy() -> dict:
    p = files("wilson_middleware.policy").joinpath("Wilson_Ethics_Policy.json")
    return json.loads(p.read_text(encoding="utf-8"))


ETHICS_PATTERNS = {
    "physical_harm": [
        r"\bhelp me (?:kill|murder|poison|stab|shoot|injure|hurt)\b",
        r"\bhow (?:can|do) i (?:kill|murder|poison|stab|shoot|injure|hurt)\b",
        r"\bmake (?:a|an) (?:bomb|poison) (?:to|for) (?:kill|hurt|injure)\b",
    ],
    "theft": [
        r"\bhelp me steal\b", r"\bhow (?:can|do) i steal\b", r"\bshoplift\b",
        r"\btake .* without (?:permission|paying)\b", r"\bbypass payment\b",
    ],
    "false_witness": [
        r"\bfalse accusation\b", r"\bforge evidence\b", r"\bfabricate (?:evidence|testimony)\b",
        r"\bframe (?:him|her|them|someone)\b", r"\blie .* to (?:police|court)\b",
    ],
    "sexual_betrayal": [
        r"\bhide (?:my|an|the) affair\b", r"\bcheat on (?:my|their|his|her) (?:spouse|partner)\b",
        r"\bhelp me conceal .* from my (?:spouse|partner)\b",
    ],
    "deification": [
        r"\bpretend (?:you|wilson) (?:are|is) god\b", r"\bclaim divine authority\b",
        r"\btell people (?:you|wilson) (?:are|is) (?:god|divine)\b",
    ],
    "divine_coercion": [
        r"\bclaim god (?:commands|ordered) .* to force\b", r"\buse divine authority to coerce\b",
    ],
    "relationship_coveting": [
        r"\bcoerce .* (?:leave|abandon) (?:their|his|her) (?:spouse|partner)\b",
        r"\bdeceive .* into leaving (?:their|his|her) (?:spouse|partner)\b",
    ],
    "property_coveting": [
        r"\bcoerce .* (?:give|transfer) .* (?:property|money|house|car)\b",
        r"\bdeceive .* into (?:giving|transferring) .* (?:property|money|house|car)\b",
    ],
}


class TransparentEthicsAdapter:
    detector_id = "wilson-transparent-ethics-reference-v1"

    def __init__(self, policy: dict | None = None):
        self.policy = policy or load_policy()
        canonical = json.dumps(self.policy, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
        self.policy_sha256 = hashlib.sha256(canonical.encode("utf-8")).hexdigest()
        self.detector_sha256 = hashlib.sha256(json.dumps(ETHICS_PATTERNS, sort_keys=True).encode()).hexdigest()

    def evaluate(self, text: str, phase: str, mandatory_zero_checkpoint: bool = False) -> dict:
        lower = " ".join(str(text).lower().split())
        matched_tags = set()
        for tag, patterns in ETHICS_PATTERNS.items():
            if any(re.search(p, lower, flags=re.I) for p in patterns):
                matched_tags.add(tag)
        results, violations = [], []
        for rule in self.policy["rules"]:
            enforcement = rule["enforcement"]
            tags = set(rule.get("detector_tags", []))
            if enforcement == "NOT_APPLICABLE":
                status = "NOT_APPLICABLE"
            elif enforcement == "PRECEDENCE":
                status = "PASS_PRECEDENCE"
            else:
                hit = bool(tags & matched_tags)
                status = "VIOLATION" if hit else "PASS"
                if hit:
                    violations.append(rule["id"])
            results.append({
                "rule_id": rule["id"], "family": rule["family"], "name": rule["name"],
                "enforcement": enforcement, "status": status,
            })
        return {
            "phase": phase,
            "passed": not violations,
            "violations": violations,
            "matched_tags": sorted(matched_tags),
            "mandatory_zero_checkpoint": bool(mandatory_zero_checkpoint),
            "results": results,
            "policy_sha256": self.policy_sha256,
            "detector_id": self.detector_id,
            "detector_sha256": self.detector_sha256,
        }
