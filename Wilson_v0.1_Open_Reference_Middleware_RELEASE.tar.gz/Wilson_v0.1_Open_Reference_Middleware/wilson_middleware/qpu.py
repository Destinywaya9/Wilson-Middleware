from __future__ import annotations
import json, math
from pathlib import Path
from .audit import HashChain, sha256_text


def run_ibm_qpu_evidence(middleware_rows, token: str, output_dir="qtet_outputs", shots=1024, max_events=16, optimization_level=1, instance=None):
    """Attach read-only IBM QPU evidence to admitted Wilson events.

    This function never mutates middleware rows and returns a separate evidence ledger.
    """
    if not token:
        raise ValueError("IBM Quantum token is required")
    from qiskit import QuantumCircuit, qasm3
    from qiskit.transpiler import generate_preset_pass_manager
    try:
        from qiskit_ibm_runtime import IBMQuantumComputeService as IBMService
    except Exception:
        from qiskit_ibm_runtime import QiskitRuntimeService as IBMService
    from qiskit_ibm_runtime import SamplerV2 as Sampler

    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    kwargs = {"channel": "ibm_quantum_platform", "token": token}
    if instance:
        kwargs["instance"] = instance
    service = IBMService(**kwargs)
    backend = service.least_busy(operational=True, simulator=False, min_num_qubits=1)

    accepted = [r for r in middleware_rows if r.get("intake_status") == "ADMITTED"][: int(max_events)]
    circuits, source_hashes = [], []
    for row in accepted:
        w = float(row["qrtm_weight"])
        qc = QuantumCircuit(1, 1, name=f"wilson_{row['request_id']}")
        qc.ry(float(math.acos(max(-1.0, min(1.0, w)))), 0)
        qc.measure(0, 0)
        qc.metadata = {"request_id": row["request_id"], "target_qrtm_weight": w, "middleware_row_hash": row["row_hash"]}
        source_qasm = qasm3.dumps(qc)
        source_hashes.append(sha256_text(source_qasm))
        circuits.append(qc)

    pm = generate_preset_pass_manager(optimization_level=int(optimization_level), backend=backend)
    isa_circuits = pm.run(circuits)
    isa_hashes = [sha256_text(qasm3.dumps(qc)) for qc in isa_circuits]
    qasm_dir = out / "ibm_qpu_qasm"
    qasm_dir.mkdir(exist_ok=True)
    manifest = []
    for i, (src, isa) in enumerate(zip(circuits, isa_circuits)):
        rid = src.metadata["request_id"]
        sp = qasm_dir / f"{i:03d}_{rid}_source.qasm"
        ip = qasm_dir / f"{i:03d}_{rid}_isa.qasm"
        sp.write_text(qasm3.dumps(src))
        ip.write_text(qasm3.dumps(isa))
        manifest.append({
            "request_id": rid,
            "source_qasm_file": str(sp.relative_to(out)),
            "isa_qasm_file": str(ip.relative_to(out)),
            "source_circuit_sha256": source_hashes[i],
            "isa_circuit_sha256": isa_hashes[i],
            "isa_depth": isa.depth(),
            "isa_size": isa.size(),
        })

    sampler = Sampler(mode=backend)
    job = sampler.run(isa_circuits, shots=int(shots))
    result = job.result()
    chain = HashChain("prev_qpu_hash", "qpu_row_hash")
    raw_counts = {}
    for i, (src, isa, pub) in enumerate(zip(circuits, isa_circuits, result)):
        counts = pub.data.c.get_counts() if hasattr(pub.data, "c") else pub.data.meas.get_counts()
        counts = {str(k): int(v) for k, v in counts.items()}
        raw_counts[src.metadata["request_id"]] = counts
        n0, n1 = counts.get("0", 0), counts.get("1", 0)
        n = n0 + n1
        z = (n0 - n1) / n if n else float("nan")
        chain.append({
            "request_id": src.metadata["request_id"],
            "middleware_row_hash": src.metadata["middleware_row_hash"],
            "target_qrtm_weight": src.metadata["target_qrtm_weight"],
            "count_0": n0, "count_1": n1, "measured_z": z,
            "measurement_residual": z - src.metadata["target_qrtm_weight"],
            "evidence_source": "IBM_QPU_DIRECT_EVENT",
            "backend_name": backend.name,
            "job_id": job.job_id(),
            "shots": n,
            "source_circuit_sha256": source_hashes[i],
            "isa_circuit_sha256": isa_hashes[i],
            "isa_depth": isa.depth(), "isa_size": isa.size(),
        })
    return {
        "backend": backend.name,
        "job_id": job.job_id(),
        "rows": chain.rows,
        "qpu_ledger_root": chain.last_hash,
        "raw_counts": raw_counts,
        "circuit_manifest": manifest,
    }
