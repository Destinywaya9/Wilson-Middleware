# Security

Do not commit API keys, tokens, passwords, or private model credentials.

For Colab + IBM Quantum, store the API key in Colab Secrets as `IBM_QUANTUM_TOKEN`.

Wilson's QPU lane is read-only evidence attachment by design. A QPU result must never be allowed to rewrite the middleware ledger, Tensor P2, QRTM intake result, or ethics decision.

If you discover a security issue in the reference implementation, report it privately to the repository maintainer before publishing exploit details.
