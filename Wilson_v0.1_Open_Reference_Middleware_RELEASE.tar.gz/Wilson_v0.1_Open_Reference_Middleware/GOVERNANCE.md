# Governance

Wilson v0.1 is released as a civilian-first, non-harm, non-weaponized reference middleware implementation.

The intended public use is research, auditability, reproducibility, model mediation, transparent experimentation, and safety/governance review.

This release is not intended for:
- weapon targeting, weapons control, or harm optimization;
- covert surveillance or profiling;
- coercive control of people;
- bypassing the mandatory ethics checkpoint contract;
- allowing a model or QPU to override Tensor P2, QRTM intake, or ethics results.

The Apache-2.0 software license defines legal permissions for the included software. This governance document records the authored project intent and design boundary; it is not a substitute for the license text.
