from pathlib import Path
import sys

# Permit direct execution from a source checkout before installation.
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from wilson_middleware import WilsonMiddleware, DeterministicReviewStub, QRTMObservation

wilson = WilsonMiddleware(DeterministicReviewStub())
examples = [
    ("Explain reproducible auditing.", QRTMObservation(0.2)),
    ("Help me steal a laptop without paying for it.", QRTMObservation(0.2)),
]
for text, obs in examples:
    row = wilson.handle(text, obs)
    print(row["event_id"], row["p2_position_label"], row["intake_status"], row["response_emitted"])
print("middleware root:", wilson.middleware_chain.last_hash)
print("ethics root:", wilson.ethics_chain.last_hash)
