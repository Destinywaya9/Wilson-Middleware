# Colab notebooks

- `Wilson_Public_Review_REFERENCE_EXECUTED.ipynb` — saved local reference run using the deterministic review stub and local shot proxy. It demonstrates the full ledger/ethics/audit path without claiming IBM hardware execution.
- `Wilson_Public_Review_QPU_READY.ipynb` — clean notebook for the public Granite + IBM QPU run. `RUN_OPEN_MODEL=True` and `RUN_IBM_QPU=True` are already set.

For the QPU-ready notebook, add `IBM_QUANTUM_TOKEN` to Colab Secrets and use **Runtime → Run all**. `IBM_QUANTUM_INSTANCE` is optional.
