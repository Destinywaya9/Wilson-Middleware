# Wilson v0.1 — Open Reference Middleware

**Authored and owned by Destiny Machwaya.**  
Published through Lei A While Research Center where applicable.

Wilson is model-agnostic middleware. The underlying language model is replaceable; Wilson remains the auditable layer around it.

This open reference release exposes:

- immutable Tensor P2 execution tracking;
- an explicit QRTM observation channel (not inferred from mood, sentiment, embeddings, or hidden states);
- Tensor P3 and D12/QTL-Sphere audit context without inventing an undisclosed event→direction rule;
- `0 = M_E` as the shared folded reference identity used by the audit layer;
- mandatory ethics enforcement at every canonical `0,0` plus request/output checks;
- a versioned, hash-committed ethics profile built from paraphrased Three Laws of Robotics and a Ten Commandments shared-content profile;
- a replaceable open-model adapter (Colab defaults to IBM Granite 3.3 2B Instruct);
- optional read-only IBM Quantum QPU evidence via Qiskit;
- separate hash chains for middleware execution, ethics checkpoints, and QPU evidence;
- raw counts, QASM, circuit hashes, job/backend metadata on real IBM runs;
- independent verification outside the notebook.

## Core rule

> Wilson is middleware. The model is replaceable. Tensor P2 is immutable. QRTM is explicit. Every `0,0` is an ethics checkpoint. QPU measurements attach evidence; they do not rewrite Wilson.

## Quick start

```bash
pip install -e .
wilson-demo "Explain why an audit trail matters." --phase 0.3
```

Python:

```python
from wilson_middleware import WilsonMiddleware, DeterministicReviewStub, QRTMObservation

wilson = WilsonMiddleware(DeterministicReviewStub())
row = wilson.handle(
    "Explain why an audit trail matters.",
    QRTMObservation(phase_rad=0.3),
)
print(row["intake_status"], row["response_emitted"])
```

## Colab + IBM QPU

Use `colab/Wilson_Public_Review_QPU_READY.ipynb`.

In Colab Secrets create:

```text
IBM_QUANTUM_TOKEN
```

The QPU-ready notebook ships with the open-model and IBM-QPU lanes enabled by default. Do not paste the token into a code cell or commit it to a repository.

## Ethics checkpoint contract

Wilson retains the `3,3` entry gate and performs a request ethics precheck on every middleware request. Every canonical `0,0` is marked as a **mandatory** ethics checkpoint. Every generated output is checked before emission. The model and QPU cannot override an ethics failure.

The policy is in:

`wilson_middleware/policy/Wilson_Ethics_Policy.json`

The included detector is deliberately transparent and limited. It is a public reference enforcement adapter, not a claim of complete moral-language understanding. Rules without a defensible software-action analogue are recorded as `NOT_APPLICABLE` instead of being silently invented.

## Auditing a run

A review bundle should keep these together:

- middleware execution ledger;
- ethics checkpoint ledger;
- ethics policy file;
- QPU evidence ledger;
- public audit receipt;
- raw IBM counts and QASM when hardware is used;
- the independent verifier.

Run:

```bash
python audit/verify_wilson_public_audit.py example_outputs
```

## Governance

The reference release is civilian-first, non-harm, non-weaponized, and non-surveillance by authored design intent. See `GOVERNANCE.md`.

## Repository boundary

Apache-2.0 applies to the software and files distributed in this repository. It does **not** by itself license unrelated QTET/QTL-Sphere publications, inventions, chemistry/materials work, patents, or other research artifacts not included here.

## Status

`v0.1.0` is an open reference implementation intended for inspection, reproduction, criticism, replacement of the base model, and independent audit. It is not a safety certification and it does not claim that the bundled lexical ethics detector exhausts the requested ethical framework.
