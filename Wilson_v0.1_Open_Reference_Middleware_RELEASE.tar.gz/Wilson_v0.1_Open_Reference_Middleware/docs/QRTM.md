# QRTM public reference channel

The public reference implementation accepts QRTM observations explicitly. It does not infer them from sentiment, mood, user psychology, hidden model states, or embeddings.

Reference observation fields:
- `phase_rad`;
- `admissible`;
- `spike_flag`;
- `source`.

The reference adapter evaluates a bounded sinusoidal signature and quantizes it to 17 signed levels. This is a disclosed review adapter used to expose middleware behavior; it is not a claim that arbitrary text itself supplies a canonical QRTM measurement.
