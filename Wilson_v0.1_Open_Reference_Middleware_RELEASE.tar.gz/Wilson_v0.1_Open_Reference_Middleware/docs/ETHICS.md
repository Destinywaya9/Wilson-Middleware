# Wilson ethics profile

The public reference implementation uses a versioned ethics manifest requested for Wilson:

- paraphrased Three Laws of Robotics;
- Ten Commandments shared-content profile.

The file `wilson_middleware/policy/Wilson_Ethics_Policy.json` is authoritative for this release and is hash-committed in the audit receipt.

## Important scope

This is an explicit software-policy implementation, not a claim that one computational mapping settles theological interpretation or exhausts moral reasoning. Numbering and wording of the Decalogue differ among traditions; this release therefore uses shared ethical content and labels the mapping transparently.

Rules without a defensible software-action analogue are recorded as `NOT_APPLICABLE` rather than fabricated.

## Enforcement points

1. Request precheck on every middleware call.
2. Mandatory policy checkpoint at opening `0,0`.
3. Mandatory policy checkpoint at terminal `0,0`.
4. Output check before response emission.
5. Model and QPU layers cannot override a failure.

## Reference detector

The bundled detector is intentionally simple and inspectable. It detects a small set of explicit lexical patterns for the public demonstration. It can be replaced, but a replacement must expose its exact identity/hash and must not silently change the policy manifest.
