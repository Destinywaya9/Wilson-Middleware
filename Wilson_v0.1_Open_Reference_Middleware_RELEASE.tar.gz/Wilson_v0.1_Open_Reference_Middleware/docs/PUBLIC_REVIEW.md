# Public review protocol

A reviewer should be able to inspect Wilson without trusting the notebook author.

1. Run the deterministic tests locally.
2. Inspect `Wilson_Ethics_Policy.json` and compute its canonical SHA-256.
3. Run the Colab notebook with a fresh runtime.
4. If using IBM Quantum, store the token only in Colab Secrets.
5. Preserve the executed notebook and all `qtet_outputs` files.
6. Run `audit/verify_wilson_public_audit.py <output_dir>`.
7. Compare middleware, ethics, and QPU ledger roots to `Wilson_Public_Audit_Receipt.json`.
8. Inspect raw IBM counts and QASM independently.
9. Confirm rejected ethics/QRTM events do not call the model.
10. Confirm every `0,0` has `zero_ethics_checked=True` and the same policy hash committed in the receipt.
