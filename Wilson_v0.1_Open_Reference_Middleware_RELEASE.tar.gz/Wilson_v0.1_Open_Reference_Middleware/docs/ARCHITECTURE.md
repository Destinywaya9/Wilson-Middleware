# Architecture

Wilson is a model-agnostic middleware layer.

```text
request + explicit QRTM observation
        |
        v
Wilson request precheck
(P2 cursor + QRTM + ethics)
        |
        +--> middleware ledger
        +--> ethics ledger
        |
        v
replaceable base model
        |
        v
output ethics check
        |
        v
emission or withholding

IBM QPU lane: read-only evidence attached after the middleware record exists.
```

## Canonical audit context

- P2: `3,3 / 0,0 / 0,1 / 1,2 / 2,1 / 1,0 / 0,0 / Delay(200)`
- P3: `[P2_1 ⊗ D_1, P2_2 ⊗ D_2, P2_3 ⊗ D_3]`
- Zero/Echo Meridian audit identity: `0 = M_E`
- D12 registry: `±X, ±Y, ±Z, XY±, YZ±, ZX±`
- Public event→direction rule: intentionally unassigned unless a canonical rule is disclosed.

## Ethics checkpoint contract

The release preserves the `3,3` entry gate and checks every request. Both `0,0` positions are mandatory ethics checkpoints. Generated output is checked before emission. Ethics decisions are policy-hash committed.

## Evidence separation

The model cannot alter Tensor P2. The QPU cannot alter the model output, QRTM intake decision, or ethics result. The QPU ledger references middleware row hashes rather than rewriting middleware rows.
