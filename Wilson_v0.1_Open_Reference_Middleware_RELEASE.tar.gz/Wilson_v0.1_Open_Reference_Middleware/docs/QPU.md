# IBM QPU evidence lane

The QPU lane is an evidence channel, not a control channel.

For each admitted event, a shallow one-qubit circuit maps the bounded QRTM review weight `w ∈ [-1,1]` to an `RY(arccos(w))` state so the ideal Z expectation is `w`.

A real run records:
- middleware request ID and row hash;
- backend and job ID;
- raw counts;
- measured Z and residual;
- source circuit and transpiled ISA circuit hashes;
- source and ISA QASM files;
- circuit depth and size;
- separate QPU hash chain.

Colab secret name: `IBM_QUANTUM_TOKEN`.

The QPU may not rewrite P2, QRTM, ethics, or model output.
