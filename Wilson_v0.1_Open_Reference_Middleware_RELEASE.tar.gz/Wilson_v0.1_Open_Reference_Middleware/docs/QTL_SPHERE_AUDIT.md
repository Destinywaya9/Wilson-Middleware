# P3 / D12 / QTL-Sphere audit context

The public audit registry exposes:

- `P3 = [P2_1 ⊗ D_1, P2_2 ⊗ D_2, P2_3 ⊗ D_3]`;
- `P3_1: (±X, ±Y)`;
- `P3_2: (±Z, XY±)`;
- `P3_3: (YZ±, ZX±)`;
- `0 = M_E`;
- the twelve-direction registry.

The visual registry is an audit map. The release intentionally records `UNASSIGNED_CANONICAL_RULE_NOT_DISCLOSED` for event→direction assignment. It does not invent a missing Wilson-event traversal rule merely to make the visualization look complete.
