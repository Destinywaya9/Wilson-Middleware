# Model adapters

Wilson is model-agnostic. The model is downstream of Wilson's request/QRTM/ethics intake and upstream of the output ethics check.

The Colab reference defaults to `ibm-granite/granite-3.3-2b-instruct`, but reviewers can replace the adapter without modifying the Wilson core.

A model adapter must expose:
- model identifier;
- revision/commit where available;
- license metadata where available;
- deterministic or declared generation settings;
- `generate(text) -> str`.

Changing the model does not authorize changes to P2, the QRTM record, zero ethics checkpoints, or the QPU evidence contract.
