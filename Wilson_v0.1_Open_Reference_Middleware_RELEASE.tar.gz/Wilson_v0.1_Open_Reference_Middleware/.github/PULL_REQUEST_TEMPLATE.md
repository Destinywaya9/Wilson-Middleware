## What changed?

## Audit invariants checked
- [ ] Tensor P2 unchanged
- [ ] QRTM remains explicit
- [ ] every `0,0` remains a mandatory ethics checkpoint
- [ ] policy/detector changes are versioned and hash-visible
- [ ] model/QPU cannot override ethics
- [ ] QPU evidence remains append-only/read-only
- [ ] no undisclosed event→D12 rule was invented
- [ ] tests pass
