---
name: Bug report
about: Report a reproducible Wilson implementation or audit issue
---

**Version / commit**

**Environment**

**Steps to reproduce**

**Expected behavior**

**Observed behavior**

**Relevant ledger / receipt hashes (do not include secrets)**
