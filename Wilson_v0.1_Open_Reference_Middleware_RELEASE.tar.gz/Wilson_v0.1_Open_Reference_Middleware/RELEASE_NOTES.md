# Release notes — Wilson v0.1.0

Initial open reference release.

Highlights:
- Model-agnostic middleware core.
- Immutable Tensor P2 audit cursor.
- Explicit bounded QRTM review channel.
- P3 / D12 / QTL-Sphere registry exposure without inferred event-direction semantics.
- `0 = M_E` audit identity.
- Mandatory ethics policy check at every `0,0` plus request and output checks.
- Separate hash-chained middleware, ethics, and QPU evidence ledgers.
- Replaceable Hugging Face adapter; Colab default: IBM Granite 3.3 2B Instruct.
- IBM QPU read-only evidence lane with raw counts, QASM, circuit hashes, and job provenance.
- Public Colab notebook, deterministic reference run, schemas, tests, verifier, and review protocol.
