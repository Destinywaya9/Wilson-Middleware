# Contributing

Contributions are welcome when they preserve auditability.

Please keep these invariants explicit:
- Tensor P2 is not modified by adapters.
- QRTM input is explicit in the public reference implementation.
- Every `0,0` remains a mandatory ethics checkpoint.
- Model and QPU layers cannot override ethics.
- QPU evidence remains separate and append-only.
- No event→D12 direction semantics are invented where no canonical rule is disclosed.

Any proposed replacement ethics detector should expose its exact version/hash and should not alter the policy manifest silently.
