# Code of Conduct

This project welcomes rigorous technical review, criticism, replication attempts, bug reports, and alternative implementations.

Participants should be respectful, evidence-focused, and free of harassment, threats, discrimination, doxxing, or deliberate misrepresentation of another contributor's work.

Disagreement with the framework, implementation, experiments, or design choices is welcome. Personal attacks are not.
