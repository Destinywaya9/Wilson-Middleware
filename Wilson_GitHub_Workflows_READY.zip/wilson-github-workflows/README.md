# Wilson GitHub Workflows

Place these files in `.github/workflows/`.

- `python-app.yml` — lint + pytest on pushes and pull requests to `main`.
- `python-publish.yml` — builds/validates the Wilson wheel and sdist, records SHA-256 values, and publishes the exact transferred artifacts to PyPI via Trusted Publishing.
- `generator-generic-ossf-slsa3-publish.yml` — builds the Wilson wheel and sdist, generates SLSA provenance over those real artifacts, and attaches the attested distributions to a published GitHub Release.

Before the first PyPI publication, configure the `pypi` GitHub Environment and the matching PyPI Trusted Publisher for this repository/workflow.
