# Security

Do not place model-service credentials or private tokens in source files, notebooks, logs, or release archives.

The rc3 live demonstration uses local Hugging Face model loading and AerSimulator. Audit outputs may contain plaintext user prompts and model responses when plaintext logging is enabled; disable or redact that logging before sharing audit artifacts if the prompts are sensitive.
