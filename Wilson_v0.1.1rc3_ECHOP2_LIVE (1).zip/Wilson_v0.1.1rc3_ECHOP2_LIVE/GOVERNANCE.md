# Governance

Destiny Machwaya is the author/owner of Wilson and the Tensor P2/QTET framework represented here.

Changes to the public reference runtime must preserve provenance, authorship, the canonical Tensor P2 sequence, the selected EchoP2 execution profile, and the hash-chained audit trail. Extended Wilson layers are not to be inferred or silently inserted into this minimal runtime.
