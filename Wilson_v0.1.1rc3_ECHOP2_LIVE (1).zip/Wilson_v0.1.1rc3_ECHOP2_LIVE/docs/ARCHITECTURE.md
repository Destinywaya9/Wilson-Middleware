# Wilson v0.1.1rc3 runtime architecture

Runtime path:

`EchoP2 -> entropy/coherence measurement -> model attach -> live user input -> model candidate -> fresh EchoP2/noise audit -> release -> repeat`

The middleware does not manufacture a P2 state from Python labels. It asks a closure engine to execute EchoP2 and validates the returned measurement record.

The public rc3 runtime intentionally excludes QRTM, Tensor P3 spatial indexing, ethics gates, and other extended Wilson layers.
