# External model adapters

Wilson accepts any adapter implementing `generate(text) -> str`.

The Colab notebook demonstrates `ibm-granite/granite-3.3-2b-instruct` through the included Hugging Face adapter.

The external model is attached only after the initial EchoP2 closure measurement validates. Each live user interaction is followed by a fresh EchoP2/noise audit before the candidate response is displayed.
