# EchoP2 execution profile

The rc3 public notebook uses `AerSimulator` with the exact supplied EchoP2 circuit and depolarizing noise `p=0.1`.

Circuit:

`H(0) -> CX(0,1) -> CX(1,2) -> CX(1,2) -> CX(0,1) -> H(0) -> Delay(200) on q0/q1/q2 -> measurement`

Default shots: `131072`.

Measured outputs: raw counts, Entropy Leakage, Coherence Fidelity, dominant state, P(000), noise provenance, and audit hashes.
