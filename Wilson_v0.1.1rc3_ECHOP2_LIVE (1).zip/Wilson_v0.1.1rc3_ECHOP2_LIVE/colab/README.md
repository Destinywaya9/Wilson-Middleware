# Colab

Use `Wilson_v0.1.1rc3_ECHOP2_LIVE.ipynb`.

The notebook executes EchoP2 with depolarizing noise p=0.1 and 131072 shots, measures entropy/coherence, attaches the external model only after the initial closure validates, and exposes a live user textbox plus live audit output. It does not use `gr.Chatbot(type=...)`.
