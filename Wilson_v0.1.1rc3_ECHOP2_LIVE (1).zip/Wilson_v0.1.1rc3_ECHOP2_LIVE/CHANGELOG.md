# Changelog

## 0.1.1rc3

- Reduced the public runtime to EchoP2 closure, entropy/coherence measurement, external-model attachment, live user UI, and per-interaction noise audit.
- Replaced the rc2 IBM-only runtime assumption with the exact supplied EchoP2 Aer demonstration: H(0), CX(0,1), CX(1,2), CX(1,2), CX(0,1), H(0), Delay(200), measurement.
- Added depolarizing noise p=0.1 on H and CX with 131072 default shots.
- Removed QRTM, Tensor P3, and ethics from the runtime path.
- Replaced version-sensitive Gradio Chatbot construction with a simple live textbox UI.
