# Packaging and release

Build the wheel from the repository root and pair it with `colab/Wilson_v0.1.1rc3_ECHOP2_LIVE.ipynb`.

Required runtime extras for the live demonstration:

- qiskit
- qiskit-aer
- transformers
- accelerate
- huggingface_hub
- torch
- gradio
- matplotlib

The live runtime is EchoP2 closure/measurement + external model + per-interaction audit.
