# Wilson v0.1.1rc3 — Tensor P2 / EchoP2 live middleware

Author and owner: Destiny Machwaya.

This release candidate intentionally keeps the public runtime small:

`Tensor P2 / EchoP2 closure -> entropy + coherence measurement -> external model connection -> live user input -> fresh P2/noise audit -> response release -> repeat`

The runtime does not require QRTM, Tensor P3 spatial indexing, ethics adapters, Pauli tomography, or other private/extended Wilson layers. Those may be demonstrated separately and adapted by readers using the monograph and accompanying explanations.

## EchoP2 demonstration kernel

The Colab release uses the supplied three-qubit EchoP2 circuit exactly:

```python
qc = QuantumCircuit(3, 3)
qc.h(0)
qc.cx(0, 1)
qc.cx(1, 2)
qc.cx(1, 2)
qc.cx(0, 1)
qc.h(0)
qc.barrier()
qc.delay(200, 0)
qc.delay(200, 1)
qc.delay(200, 2)
qc.measure([0, 1, 2], [0, 1, 2])
```

The demonstration noise stream is depolarizing noise with `p=0.1` on `h` and `cx`, run with `131072` shots by default.

The canonical Tensor P2 state sequence remains:

`3,3 / 0,0 / 0,1 / 1,2 / 2,1 / 1,0 / 0,0 / Delay(200)`

## Measurements

Wilson exposes the existing measurement function directly:

- Entropy Leakage = Shannon entropy of measured bit-string probabilities, in bits.
- Coherence Fidelity = maximum measured outcome probability × 100.
- Raw counts, dominant state, `P(000)`, noise provenance, and hash-chained audit records are retained.

No new acceptance threshold is introduced by the middleware. The terminal `0,0` / `000` closure outcome must remain the dominant measured state for the middleware to release an external-model candidate.

## Live UI

The Colab notebook uses a simple live textbox interface instead of a version-sensitive `gr.Chatbot(type=...)` constructor. Every submitted user prompt calls the external model and then runs a fresh EchoP2 audit before displaying the candidate response.

See `colab/Wilson_v0.1.1rc3_ECHOP2_LIVE.ipynb`.
