from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from wilson_middleware import EchoP2AerEngine, WilsonMiddleware, DeterministicReviewStub

engine = EchoP2AerEngine(shots=4096, depolarizing_probability=0.1)
wilson = WilsonMiddleware(engine)
print("initial status:", wilson.live_status())

wilson.attach_model(DeterministicReviewStub())
row = wilson.interact("Explain reproducible auditing.")
print("interaction:", row["interaction_status"])
print("response:", row["model_output"])
print("live status:", wilson.live_status())
print("audit root:", wilson.audit_chain.last_hash)
print("interaction root:", wilson.interaction_chain.last_hash)
