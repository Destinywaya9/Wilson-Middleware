# Wilson v0.1.1rc3 release notes

This candidate is deliberately minimal. Wilson executes and measures EchoP2 before any external model attaches. Live user input is sent to the external model, then a fresh EchoP2 run audits the depolarizing noise stream and closure before the candidate response is displayed.

The visible audit reports Entropy Leakage, Coherence Fidelity, raw counts, dominant state, P(000), shots, noise source, environment generation, and hash-chain roots.
