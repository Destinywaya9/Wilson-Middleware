# Contributing

Keep the public rc3 runtime narrow and auditable:

`EchoP2 -> measurement -> model attach -> live interaction -> fresh EchoP2/noise audit -> release`

Do not silently alter the canonical Tensor P2 sequence, the supplied EchoP2 circuit, Delay(200), the entropy/coherence measurement function, or the audit ordering.

Extended Wilson layers are outside the rc3 runtime and should be kept separate unless explicitly added in a later release.
