from wilson_middleware import WilsonMiddleware, DeterministicReviewStub, P2_FULL
from wilson_middleware.models import BaseModelAdapter
from wilson_middleware.qpu import ECHOP2_GATE_SEQUENCE, P2_SEQUENCE


class FakeP2Engine:
    expected_p2_sequence = P2_SEQUENCE
    expected_gate_sequence = ECHOP2_GATE_SEQUENCE

    def __init__(self, *, closure_state_ok=True, entropy=0.125, fidelity=97.5):
        self.calls = []
        self.closure_state_ok = closure_state_ok
        self.entropy = entropy
        self.fidelity = fidelity

    def run(self, *, tag="p2-closure"):
        self.calls.append(tag)
        i = len(self.calls)
        return {
            "audit_tag": tag,
            "backend_name": "aer_simulator",
            "job_id": f"aer-{i}",
            "shots": 131072,
            "kernel": "Tensor P2 / EchoP2",
            "p2_sequence": " / ".join(P2_SEQUENCE),
            "gate_sequence": " / ".join(ECHOP2_GATE_SEQUENCE),
            "entry_stage": "3,3",
            "terminal_closure_stage": "0,0",
            "delay_value": 200,
            "delay_unit": "qiskit_default",
            "noise_source": "AER_DEPOLARIZING_P_0.1",
            "noise_stream_present": True,
            "noise_stream_kind": "depolarizing",
            "depolarizing_probability": 0.1,
            "synthetic_noise_injected": True,
            "aer_noise_model_used": True,
            "pauli_tomography": False,
            "counts": {"000": 120000, "001": 11072},
            "entropy_leakage_bits": self.entropy,
            "coherence_fidelity_percent": self.fidelity,
            "expected_closure_state": "000",
            "expected_closure_probability": 120000 / 131072,
            "dominant_state": "000" if self.closure_state_ok else "111",
            "closure_state_ok": self.closure_state_ok,
            "source_circuit_sha256": "a" * 64,
            "transpiled_circuit_sha256": "b" * 64,
        }


class CountingModel(BaseModelAdapter):
    model_id = "counting-model"
    revision = "test"
    license = "test"
    backend = "test"

    def __init__(self):
        self.calls = 0

    def generate(self, text: str) -> str:
        self.calls += 1
        return f"candidate:{text}"


def test_bootstrap_runs_p2_before_model_connection():
    engine = FakeP2Engine()
    w = WilsonMiddleware(engine)
    assert engine.calls == ["environment-bootstrap"]
    assert w.environment_locked is True
    assert w.model is None
    assert w.verify_kernel()
    assert tuple(P2_SEQUENCE) == P2_FULL
    assert w.latest_measurement["entropy_leakage_bits"] == 0.125
    assert w.latest_measurement["coherence_fidelity_percent"] == 97.5


def test_external_model_cannot_connect_until_measurement_validates():
    engine = FakeP2Engine(closure_state_ok=False)
    try:
        WilsonMiddleware(engine)
    except RuntimeError as exc:
        assert "did not validate" in str(exc)
    else:
        raise AssertionError("invalid closure should fail bootstrap")


def test_model_connection_occurs_after_bootstrap():
    engine = FakeP2Engine()
    model = CountingModel()
    w = WilsonMiddleware(engine)
    info = w.attach_model(model)
    assert info["model_connected"] is True
    assert model.calls == 0
    assert w.environment_locked is True


def test_live_interaction_model_then_fresh_p2_closure_before_release():
    engine = FakeP2Engine()
    model = CountingModel()
    w = WilsonMiddleware(engine)
    w.attach_model(model)
    row = w.interact("hello", request_id="live-test")
    assert model.calls == 1
    assert engine.calls == ["environment-bootstrap", "interaction:live-test"]
    assert row["p2_locked_before_model"] is True
    assert row["post_p2_closure_complete"] is True
    assert row["response_emitted"] is True
    assert row["interaction_status"] == "EMITTED_AFTER_P2_CLOSURE"
    assert row["model_output"] == "candidate:hello"


def test_failed_post_model_p2_closure_withholds_candidate():
    class FailOnSecond(FakeP2Engine):
        def run(self, *, tag="p2-closure"):
            record = super().run(tag=tag)
            if len(self.calls) >= 2:
                record["dominant_state"] = "111"
                record["closure_state_ok"] = False
            return record

    engine = FailOnSecond()
    model = CountingModel()
    w = WilsonMiddleware(engine)
    w.attach_model(model)
    row = w.interact("hello", request_id="fail-test")
    assert model.calls == 1
    assert row["response_emitted"] is False
    assert row["interaction_status"] == "WITHHELD_P2_CLOSURE_FAILED"
    assert row["model_output"] == ""
    assert w.environment_locked is False


def test_manual_audit_updates_live_measurement():
    engine = FakeP2Engine()
    w = WilsonMiddleware(engine)
    result = w.audit_now(tag="manual")
    assert engine.calls == ["environment-bootstrap", "manual"]
    assert result["job_id"] == "aer-2"
    assert w.live_status()["job_id"] == "aer-2"


def test_live_status_exposes_noise_entropy_and_coherence():
    engine = FakeP2Engine()
    w = WilsonMiddleware(engine)
    status = w.live_status()
    assert status["noise_source"] == "AER_DEPOLARIZING_P_0.1"
    assert status["depolarizing_probability"] == 0.1
    assert status["entropy_leakage_bits"] == 0.125
    assert status["coherence_fidelity_percent"] == 97.5


def test_hash_chains_verify():
    engine = FakeP2Engine()
    w = WilsonMiddleware(engine, DeterministicReviewStub())
    for i in range(3):
        w.interact(f"hello {i}")
    assert w.verify_audit_chain()
    assert w.verify_chain()
