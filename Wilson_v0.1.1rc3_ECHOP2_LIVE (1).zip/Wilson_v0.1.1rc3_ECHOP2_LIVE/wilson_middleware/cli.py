from __future__ import annotations

import argparse
import json

from .middleware import WilsonMiddleware
from .models import DeterministicReviewStub
from .qpu import EchoP2AerEngine


def main():
    ap = argparse.ArgumentParser(
        description="Wilson EchoP2 closure + entropy/coherence live-audit demo"
    )
    ap.add_argument("text")
    ap.add_argument("--shots", type=int, default=131072)
    ap.add_argument("--noise", type=float, default=0.1)
    args = ap.parse_args()

    engine = EchoP2AerEngine(
        shots=args.shots,
        depolarizing_probability=args.noise,
    )
    wilson = WilsonMiddleware(engine)
    wilson.attach_model(DeterministicReviewStub())
    row = wilson.interact(args.text)
    print(json.dumps(row, indent=2, default=str))


if __name__ == "__main__":
    main()
