from .canon import P2_FULL, P3_FORM, ECHO_MERIDIAN_ZERO, D12
from .models import BaseModelAdapter, DeterministicReviewStub
from .middleware import WilsonMiddleware, P2ClosureEngine
from .qpu import (
    EchoP2AerEngine,
    P2_SEQUENCE,
    ECHOP2_GATE_SEQUENCE,
    P2_QPU_SEQUENCE,
    P2_QPU_GATE_SEQUENCE,
    build_echo_p2_circuit,
    build_depolarizing_noise_model,
    compute_entropy_and_fidelity,
)

__version__ = "0.1.1rc3"
__all__ = [
    "P2_FULL",
    "P3_FORM",
    "ECHO_MERIDIAN_ZERO",
    "D12",
    "BaseModelAdapter",
    "DeterministicReviewStub",
    "WilsonMiddleware",
    "P2ClosureEngine",
    "EchoP2AerEngine",
    "P2_SEQUENCE",
    "ECHOP2_GATE_SEQUENCE",
    "P2_QPU_SEQUENCE",
    "P2_QPU_GATE_SEQUENCE",
    "build_echo_p2_circuit",
    "build_depolarizing_noise_model",
    "compute_entropy_and_fidelity",
]
