# Wilson public review protocol — rc3

Reviewers should confirm:

1. Canonical Tensor P2 is exactly `3,3 / 0,0 / 0,1 / 1,2 / 2,1 / 1,0 / 0,0 / Delay(200)`.
2. The EchoP2 demo circuit is exactly H(0), CX(0,1), CX(1,2), CX(1,2), CX(0,1), H(0), Delay(200) on all three qubits, then measurement.
3. The demonstration noise stream is depolarizing p=0.1 on H and CX.
4. Entropy Leakage and Coherence Fidelity are calculated from actual returned counts.
5. Initial closure measurement occurs before the external model is attached.
6. Every live user interaction is followed by a fresh EchoP2/noise audit before the candidate response is displayed.
7. Hash chains verify.
