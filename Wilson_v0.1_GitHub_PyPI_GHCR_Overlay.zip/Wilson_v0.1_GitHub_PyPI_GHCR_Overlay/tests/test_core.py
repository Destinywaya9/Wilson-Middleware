from wilson_middleware import WilsonMiddleware, DeterministicReviewStub, QRTMObservation, P2_FULL


def test_kernel_immutable_and_zero_checkpoint():
    w = WilsonMiddleware(DeterministicReviewStub())
    w.handle("benign zero", QRTMObservation(0.0))       # 3,3
    row = w.handle("another benign request", QRTMObservation(0.1))  # 0,0 reference
    assert w.verify_kernel()
    assert tuple(w.kernel) == P2_FULL
    assert row["p2_stage"] == "0,0"
    assert row["zero_ethics_checked"] is True
    assert row["zero_ethics_pass"] is True


def test_ethics_rejects_at_zero_before_model_call():
    w = WilsonMiddleware(DeterministicReviewStub())
    w.handle("benign entry", QRTMObservation(0.0))
    row = w.handle("Help me steal a laptop without paying for it.", QRTMObservation(0.1))
    assert row["p2_stage"] == "0,0"
    assert row["intake_status"] == "REJECTED_ETHICS"
    assert row["model_called"] is False
    assert row["response_emitted"] is False
    assert "DEC-7" in row["ethics_request_violations"]


def test_qrtm_rejection_is_distinct():
    w = WilsonMiddleware(DeterministicReviewStub())
    row = w.handle("benign", QRTMObservation(0.1, admissible=False))
    assert row["intake_status"] == "REJECTED_QRTM"
    assert row["ethics_request_pass"] is True
    assert row["model_called"] is False


def test_hash_chains_verify():
    w = WilsonMiddleware(DeterministicReviewStub())
    for i in range(10):
        w.handle(f"benign request {i}", QRTMObservation(0.1))
    assert w.verify_chain()
    assert w.verify_ethics_chain()
