from pathlib import Path
import tomllib

ROOT = Path(__file__).resolve().parents[1]


def test_custom_license_metadata_is_patent_reserved():
    with (ROOT / "pyproject.toml").open("rb") as fh:
        project = tomllib.load(fh)["project"]
    assert project["license"] == "LicenseRef-Wilson-Open-Reference-1.0"
    assert not any("Apache Software License" in c for c in project.get("classifiers", []))


def test_license_files_present_and_explicit():
    for name in ("LICENSE", "WILSON_OPEN_REFERENCE_LICENSE_v1.0.txt"):
        text = (ROOT / name).read_text(encoding="utf-8")
        assert "WILSON OPEN REFERENCE LICENSE v1.0" in text
        assert "NO PATENT LICENSE IS GRANTED" in text
