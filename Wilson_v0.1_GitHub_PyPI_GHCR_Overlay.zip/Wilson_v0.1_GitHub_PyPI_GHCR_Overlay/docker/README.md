# Wilson container

The default image installs Wilson with the `qpu` and `review` extras. It does not bake credentials into the image.

Build locally:

```bash
docker build -t wilson-open-middleware:0.1.0 .
```

Run the deterministic reference middleware:

```bash
docker run --rm wilson-open-middleware:0.1.0 "Hello Wilson" --phase 0.2
```

Build the larger image with Hugging Face model support as well:

```bash
docker build --build-arg WILSON_EXTRAS=all -t wilson-open-middleware:0.1.0-full .
```

Do not put `IBM_QUANTUM_TOKEN` in the Dockerfile or image layers. Pass credentials at runtime only when a script actually needs them.
