# Wilson v0.1 Packaging and Release

Wilson uses three complementary distribution surfaces:

1. **GitHub Releases** — canonical source/release record, audit artifacts, notebooks, checksums, and build attestations.
2. **PyPI** — convenient installation of the Python middleware package.
3. **GitHub Container Registry (GHCR)** — optional reproducible container distribution.

Wilson itself is source-available under the **Wilson Open Reference License v1.0 — Patent Rights Reserved**. The Python metadata uses `LicenseRef-Wilson-Open-Reference-1.0`.

## Local package validation

```bash
python -m pip install -r requirements-dev.txt
python tools/license_guard.py
python -m pytest tests -q
python -m build
python -m twine check dist/*
sha256sum dist/*.whl dist/*.tar.gz
```

Install the wheel into a clean environment and smoke-test it:

```bash
python -m venv .release-venv
. .release-venv/bin/activate
python -m pip install dist/*.whl
wilson-demo "release smoke test" --phase 0.0
```

## PyPI one-time setup

The workflow `.github/workflows/release-python.yml` uses PyPI Trusted Publishing (OIDC), so no long-lived PyPI API token is stored in GitHub.

Before the first release, configure a PyPI Trusted Publisher for:

- repository: your Wilson repository;
- workflow filename: `release-python.yml`;
- environment: `pypi`;
- project name: `wilson-open-middleware` (or the final PyPI name you reserve).

Then publish a GitHub Release. The workflow tests, builds, checks, attests, attaches, and publishes the exact distributions.

## GHCR

The workflow `.github/workflows/publish-container.yml` publishes to:

```text
ghcr.io/<owner>/<repository>
```

It uses the repository `GITHUB_TOKEN`; no separate GHCR password is required in GitHub Actions.

The default image installs Wilson with the `qpu` and `review` extras. For a local image with Hugging Face support too:

```bash
docker build --build-arg WILSON_EXTRAS=all -t wilson-open-middleware:0.1.0-full .
```

Credentials such as `IBM_QUANTUM_TOKEN` must be supplied only at runtime and must never be placed in the image or repository.

## Verify GitHub build attestations

For a downloaded wheel:

```bash
gh attestation verify dist/wilson_open_middleware-0.1.0-py3-none-any.whl -R OWNER/REPOSITORY
```

For a GHCR image:

```bash
gh attestation verify oci://ghcr.io/OWNER/REPOSITORY:TAG -R OWNER/REPOSITORY
```

## Release order

1. Confirm `python tools/license_guard.py` passes.
2. Confirm `python -m pytest tests -q` passes.
3. Create a tagged GitHub release such as `v0.1.0`.
4. Allow the Python and GHCR workflows to complete.
5. Download and independently verify the published artifacts and attestations.
6. Attach IBM-QPU run evidence only after a real hardware run; never label local proxy evidence as hardware evidence.
