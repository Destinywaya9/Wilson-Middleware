from __future__ import annotations

from pathlib import Path
import sys
import tomllib

ROOT = Path(__file__).resolve().parents[1]
EXPECTED = "LicenseRef-Wilson-Open-Reference-1.0"

errors: list[str] = []

pyproject_path = ROOT / "pyproject.toml"
with pyproject_path.open("rb") as fh:
    project = tomllib.load(fh)["project"]

if project.get("license") != EXPECTED:
    errors.append(f"pyproject.toml project.license must be {EXPECTED!r}")

for classifier in project.get("classifiers", []):
    if "Apache Software License" in classifier:
        errors.append("pyproject.toml still advertises Apache-2.0 for Wilson")

for name in ["LICENSE", "WILSON_OPEN_REFERENCE_LICENSE_v1.0.txt"]:
    path = ROOT / name
    if not path.exists():
        errors.append(f"missing {name}")
        continue
    text = path.read_text(encoding="utf-8", errors="replace")
    if "WILSON OPEN REFERENCE LICENSE v1.0" not in text:
        errors.append(f"{name} is not the Wilson Open Reference License v1.0")
    if "NO PATENT LICENSE IS GRANTED" not in text:
        errors.append(f"{name} does not contain the explicit patent reservation")

# Granite's third-party Apache-2.0 license is permitted. What is forbidden here is
# metadata or top-level license text that applies Apache-2.0 to Wilson itself.
critical = ["pyproject.toml", "LICENSE", "NOTICE", "GOVERNANCE.md", "CITATION.cff"]
for name in critical:
    path = ROOT / name
    if path.exists():
        text = path.read_text(encoding="utf-8", errors="replace")
        if "License :: OSI Approved :: Apache Software License" in text:
            errors.append(f"{name} contains the old Apache classifier")

if errors:
    print("Wilson license guard FAILED:")
    for error in errors:
        print(f" - {error}")
    sys.exit(1)

print("Wilson license guard PASSED")
print(f"License expression: {EXPECTED}")
